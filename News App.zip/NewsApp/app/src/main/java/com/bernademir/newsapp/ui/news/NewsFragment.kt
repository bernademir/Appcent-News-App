package com.bernademir.newsapp.ui.news

import android.app.SearchManager
import android.content.Context

import android.os.Bundle
import android.util.Log
import android.view.Menu
import android.view.MenuInflater
import android.view.MenuItem
import android.view.View
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SearchView
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.bernademir.newsapp.R
import com.bernademir.newsapp.adapter.ArticleAdapter
import com.bernademir.newsapp.api.EverythingEndpoint
import com.bernademir.newsapp.model.Article
import com.bernademir.newsapp.model.Everything
import com.jakewharton.retrofit2.adapter.rxjava2.RxJava2CallAdapterFactory
import io.reactivex.disposables.CompositeDisposable
import io.reactivex.observers.DisposableObserver
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import io.reactivex.schedulers.Schedulers
import io.reactivex.Observable
import io.reactivex.android.schedulers.AndroidSchedulers


class NewsFragment : AppCompatActivity(), SwipeRefreshLayout.OnRefreshListener {


    private val ENDPOINT_URL by lazy { "https://newsapi.org/v2/" }
    private lateinit var everythingEndpoint: EverythingEndpoint
    private lateinit var newsApiConfig: String
    private lateinit var articleAdapter: ArticleAdapter
    private lateinit var articleList: ArrayList<Article>
    private lateinit var userKeyWordInput: String
    // RxJava related fields
    private lateinit var everythingObservable: Observable<Everything>
    private lateinit var compositeDisposable: CompositeDisposable


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.fragment_news)
        //Network request
        val retrofit: Retrofit = generateRetrofitBuilder()
        everythingEndpoint = retrofit.create(EverythingEndpoint::class.java)
        newsApiConfig = resources.getString(R.string.api_key)
        findViewById<SwipeRefreshLayout>(R.id.swipe_refresh).setOnRefreshListener(this)
        findViewById<SwipeRefreshLayout>(R.id.swipe_refresh).setColorSchemeResources(R.color.black)
        articleList = ArrayList()
        articleAdapter = ArticleAdapter(articleList)
        //When the app is launched of course the user input is empty.
        userKeyWordInput = ""
        //CompositeDisposable is needed to avoid memory leaks
        compositeDisposable = CompositeDisposable()
        findViewById<RecyclerView>(R.id.recycler_view).setHasFixedSize(true)
        findViewById<RecyclerView>(R.id.recycler_view).layoutManager = LinearLayoutManager(this)
        findViewById<RecyclerView>(R.id.recycler_view).itemAnimator = DefaultItemAnimator()
        findViewById<RecyclerView>(R.id.recycler_view).adapter = articleAdapter

    }

    override fun onDestroy() {
        super.onDestroy()
        compositeDisposable.clear()
    }

    override fun onRefresh() {
        checkUserKeywordInput()
    }

    private fun checkUserKeywordInput() {
        if (userKeyWordInput.isEmpty()) {
            queryTopHeadlines()
        } else {
            getKeyWordQuery(userKeyWordInput)
        }
    }

    private fun generateRetrofitBuilder(): Retrofit {

        return Retrofit.Builder()
            .baseUrl(ENDPOINT_URL)
            .addConverterFactory(GsonConverterFactory.create())
            //Add RxJava2CallAdapterFactory as a Call adapter when building your Retrofit instance
            .addCallAdapterFactory(RxJava2CallAdapterFactory.create())
            .build()
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        if (menu != null) {
            val inflater: MenuInflater = menuInflater
            inflater.inflate(R.menu.bottom_nav_search, menu)
            //Creates input field for the user search
            setUpSearchMenuItem(menu)
        }
        return true
    }

    private fun setUpSearchMenuItem(menu: Menu) {
        val searchManager: SearchManager = (getSystemService(Context.SEARCH_SERVICE)) as SearchManager
        val searchView: SearchView = ((menu.findItem(R.id.action_search)?.actionView)) as SearchView
        val searchMenuItem: MenuItem = menu.findItem(R.id.action_search)

        searchView.setSearchableInfo(searchManager.getSearchableInfo(componentName))
        searchView.queryHint = "Type any keyword to search..."
        searchView.setOnQueryTextListener(onQueryTextListenerCallback())
        searchMenuItem.icon.setVisible(false, false)
    }

    //Gets immediately triggered when user clicks on search icon and enters something
    private fun onQueryTextListenerCallback(): SearchView.OnQueryTextListener {
        return object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(userInput: String?): Boolean {
                return checkQueryText(userInput)
            }

            override fun onQueryTextChange(userInput: String?): Boolean {
                return checkQueryText(userInput)
            }
        }
    }

    private fun checkQueryText(userInput: String?): Boolean {
        if (userInput != null && userInput.length > 1) {
            userKeyWordInput = userInput
            getKeyWordQuery(userInput)
        } else if (userInput != null && userInput == "") {
            userKeyWordInput = ""
            queryTopHeadlines()
        }
        return false
    }

    private fun getKeyWordQuery(userKeywordInput: String) {
        findViewById<SwipeRefreshLayout>(R.id.swipe_refresh).isRefreshing = true
        if (userKeywordInput.isNotEmpty()) {
            everythingObservable = everythingEndpoint.getUserSearchInput(newsApiConfig, userKeywordInput)
            subscribeObservableOfArticle()
        } else {
            queryTopHeadlines()
        }
    }

    private fun queryTopHeadlines() {
        findViewById<SwipeRefreshLayout>(R.id.swipe_refresh).isRefreshing = true
        everythingObservable = everythingEndpoint.getEverything("tr", newsApiConfig)
        subscribeObservableOfArticle()
    }

    private fun subscribeObservableOfArticle() {
        articleList.clear()
        compositeDisposable.add(
            everythingObservable.subscribeOn(Schedulers.io())
                .observeOn(AndroidSchedulers.mainThread())
                .flatMap {
                    Observable.fromIterable(it.articles)
                }
                .subscribeWith(createArticleObserver())
        )
    }

    private fun createArticleObserver(): DisposableObserver<Article> {
        return object : DisposableObserver<Article>() {
            override fun onNext(article: Article) {
                if (!articleList.contains(article)) {
                    articleList.add(article)
                }
            }

            override fun onComplete() {
                showArticlesOnRecyclerView()
            }

            override fun onError(e: Throwable) {
                Log.e("createArticleObserver", "Article error: ${e.message}")
            }
        }
    }

    private fun showArticlesOnRecyclerView() {
        if (articleList.size > 0) {
            findViewById<TextView>(R.id.empty_text).visibility = View.GONE
            findViewById<RecyclerView>(R.id.recycler_view).visibility = View.GONE
            findViewById<RecyclerView>(R.id.recycler_view).visibility = View.VISIBLE
            articleAdapter.setArticles(articleList)
        } else {
            findViewById<RecyclerView>(R.id.recycler_view).visibility = View.GONE
            findViewById<TextView>(R.id.empty_text).visibility = View.VISIBLE
            findViewById<RecyclerView>(R.id.recycler_view).visibility = View.VISIBLE
            findViewById<RecyclerView>(R.id.recycler_view).setOnClickListener { checkUserKeywordInput() }
        }
        findViewById<SwipeRefreshLayout>(R.id.swipe_refresh).isRefreshing = false
    }
}